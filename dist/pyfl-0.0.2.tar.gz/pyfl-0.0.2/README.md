# WIP Package

This package is very much a WIP, please bear with me while I develop it

## Features
- Active python library developed specifically for the TFL API
- Asynchronous
- Object Orientated Code

## Installation

To install the latest and most stable version:
```
pip install pyfl
```

To install the development version (not recommended):
```
pip install git+https://github.com/wotanut/pyfl.git
```

Or via git
```
git clone https://github.com/wotanut/pyfl
```

## Useful links
there are none yet
